<?php
/**
 * Description of ${name}
 *
 * @author ${user}
 * @package 
 */

class Wpjb_Application_Resumes extends Wpjb_Application_Frontend
{

}

?>
