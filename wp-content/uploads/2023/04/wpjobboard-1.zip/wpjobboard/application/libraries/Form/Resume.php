<?php

    /**
     * Description of Resume
     *
     * @author greg
     * @package
     */
    class Wpjb_Form_Resume extends Wpjb_Form_Abstract_Resume
    {

        public function init()
        {
            parent::init();
            $this->removeElement("is_approved");
            $this->removeElement("status");

            if ($this->isNew() && current_user_can("manage_resumes")) {
                $user = new WP_User(get_current_user_id());
                $default = array("first_name", "last_name", "user_email", "user_url");
                foreach ($default as $key) {
                    if ($this->hasElement($key)) {
                        $this->getElement($key)->setValue($user->$key);
                    }
                }
            }

            add_filter("wpjr_form_init_resume", array($this, "apply"), 9);
            apply_filters("wpjr_form_init_resume", $this);
        }

        public function save($append = array())
        {
            if ($this->hasElement("modified_at")) {
                $this->removeElement("modified_at");
            }

            $today = date("Y-m-d H:i:s");

            $append = array("modified" => $today);


            if ($this->isNew()) {
                $title = trim($this->value("first_name") . " " . $this->value("last_name"));
                $append["user_id"] = get_current_user_id();
                $append["candidate_slug"] = Wpjb_Utility_Slug::generate("resume", $title, $this->getId());
            }

            parent::save($append);

            $last_sent_notify = get_user_meta(get_current_user_id(), 'last_send_notify', true);

            if (empty($last_sent_notify)) {
                $this->send_notify();
                add_user_meta(get_current_user_id(), 'last_send_notify', date("Y-m-d H:i:s"));
            } else {
                $instance = Wpjb_Project::getInstance();
                $time_notify = $instance->getConfig("job_board_notify_time", "1");
                $date1 = strtotime($today);
                $date2 = strtotime($last_sent_notify);
                $diff = $date1 - $date2;

                if ($diff >= $time_notify * 3600) {
                    $files = array();
                    $this->send_notify();
                    update_user_meta(get_current_user_id(), 'last_send_notify', date("Y-m-d H:i:s"));
                }
            }
            do_action("wpjb_resume_saved", $this->getObject());
            apply_filters("wpjr_form_save_resume", $this);

        }


        public function send_notify()
        {
            foreach ($this->getFiles() as $f) {
                $files[] = $f->dir;
            }

            $instance = Wpjb_Project::getInstance();
            $mail = Wpjb_Utility_Message::load("-resume_update");
            $mail->assign("resume", Wpjb_Model_Resume::current());
            $mail->addFiles($files);
            $mail->setTo($instance->getConfig('job_board_admin_email', get_option("admin_email")));
            $mail->send();
        }

        public function getFiles()
        {
            $upload = wpjb_upload_dir("resume", "cvonline", $this->getId());
            $baseurl = $upload["baseurl"];
            $upload = $upload["basedir"] . "/*";
            $files = wpjb_glob($upload);

            $fArr = array();
            foreach ($files as $file) {
                $dir = basename(dirname($file));
                $f = new stdClass;
                $f->basename = basename($file);
                $f->url = str_replace("*", $dir, $baseurl) . "/" . $f->basename;
                $f->size = filesize($file);
                $f->ext = pathinfo($file, PATHINFO_EXTENSION);
                $f->dir = $file;
                $fArr[] = $f;
            }

            $upload = wpjb_upload_dir("resume", "image", $this->getId());
            $baseurl = $upload["baseurl"];
            $upload = $upload["basedir"] . "/*";
            $files = wpjb_glob($upload);

            foreach ($files as $file) {
                $dir = basename(dirname($file));
                $f = new stdClass;
                $f->basename = basename($file);
                $f->url = str_replace("*", $dir, $baseurl) . "/" . $f->basename;
                $f->size = filesize($file);
                $f->ext = pathinfo($file, PATHINFO_EXTENSION);
                $f->dir = $file;
                $fArr[] = $f;
            }


            return $fArr;
        }


    }

?>