<?php
/**
 * Description of Alert
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_AlertStat extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_alert_email_sent";

    protected function _init()
    {
        
    }
}

?>