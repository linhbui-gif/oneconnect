<?php

/**
 * Description of Login
 *
 * @author greg
 * @package
 */

class Wpjb_Form_Resumes_Register extends Daq_Form_Abstract
{
    public function init()
    {
        if(!is_admin()) {
            $e = $this->create("_wpjb_action", "hidden");
            $e->setValue("reg_candidate");
            $this->addElement($e, "_internal");
        }
        
        $this->addGroup("default", __("Register", "wpjobboard"));

        $e = $this->create("firstname");
        $e->setLabel(__("First name", "wpjobboard"));
        $e->setRequired(true);
        $this->addElement($e, "default");
        
        $e = $this->create("lastname");
        $e->setLabel(__("Last name", "wpjobboard"));
        $e->setRequired(true);
        $this->addElement($e, "default");
        
        $e = $this->create("user_login");
        $e->setLabel(__("Username", "wpjobboard"));
        $e->setRequired(true);
        $e->addFilter(new Daq_Filter_Trim());
        $e->addFilter(new Daq_Filter_WP_SanitizeUser());
        $e->addValidator(new Daq_Validate_WP_Username());
        $this->addElement($e, "default");
        
        $e = $this->create("user_password", "password");
        $e->setLabel(__("Password", "wpjobboard"));
        $e->addFilter(new Daq_Filter_Trim());
        $e->addValidator(new Daq_Validate_StringLength(4, 32));
        $e->addValidator(new Daq_Validate_PasswordEqual("user_password2"));
        $e->setRequired(true);
        $this->addElement($e, "default");

        $e = $this->create("user_password2", "password");
        $e->setLabel(__("Password (repeat)", "wpjobboard"));
        $e->setRequired(true);
        $this->addElement($e, "default");
		
		//$e = $this->create("phone");
       //$e->setValue($this->_object->phone);
       // $e->setRequired(true);
        //$e->setLabel(__("Phone", "wpjobboard"));
        //$this->addElement($e, "phone");
		
        $e = $this->create("user_email");
        $e->setLabel(__("E-mail", "wpjobboard"));
        $e->addFilter(new Daq_Filter_Trim());
        $e->addValidator(new Daq_Validate_WP_Email());
        $e->setRequired(true);
        $this->addElement($e, "default");


        $this->addGroup("location", __("Address", "wpjobboard"));

        $def = wpjb_locale();
        $e = $this->create("candidate_country", "select");
        $e->setLabel(__("Country", "wpjobboard"));
        $e->setRequired(true);
        $e->setValue(($this->_object->candidate_country) ? $this->_object->candidate_country : $def);
        $e->addOptions(wpjb_form_get_countries());
        $e->addClass("wpjb-location-country");
        $this->addElement($e, "location");
/*
        $e = $this->create("candidate_state");
        $e->setLabel(__("State", "wpjobboard"));
        $e->setValue($this->_object->candidate_state);
        $e->addClass("wpjb-location-state");
        $this->addElement($e, "location");

        $e = $this->create("candidate_zip_code");
        $e->setLabel(__("Zip-Code", "wpjobboard"));
        $e->addValidator(new Daq_Validate_StringLength(null, 20));
        $e->setValue($this->_object->candidate_zip_code);
        $this->addElement($e, "location");
*/
       $e = $this->create("candidate_location");
       $e->setValue($this->_object->candidate_location);
        $e->setRequired(true);
        $e->setLabel(__("City", "wpjobboard"));
        $e->setHint(__('For example: "Chicago", "London", "Anywhere" or "Telecommute".', "wpjobboard"));
        $e->addValidator(new Daq_Validate_StringLength(null, 120));
        $e->addClass("wpjb-location-city");
        $this->addElement($e, "location");

        apply_filters("wpjr_form_init_register", $this);
    }

    public function save()
    {      
        $id = wp_insert_user(array(
            "user_login" => $this->getElement("user_login")->getValue(), 
            "user_email" => $this->getFieldValue("user_email"), 
            "user_pass" => $this->getElement("user_password")->getValue(),
            "first_name" => $this->getFieldValue("firstname"),
            "last_name" => $this->getFieldValue("lastname"),
			//"phone" => $this->getFieldValue("phone"),
            "role" => "subscriber"
        ));

        $fullname = $this->value("firstname")." ".$this->value("lastname");
        
        if(wpjb_conf("cv_approval") == 1) {
            $active = 0; // manual approval
        } else {
            $active = 1;
        }
        
        $resume = new Wpjb_Model_Resume();
        $resume->candidate_slug = Wpjb_Utility_Slug::generate(Wpjb_Utility_Slug::MODEL_RESUME, $fullname);
        $resume->phone = "";
        $resume->user_id = $id;
        $resume->headline = "";
       $resume->description = "";
      $resume->created_at = date("Y-m-d");
        $resume->modified_at = date("Y-m-d");
        $resume->candidate_country = $this->getFieldValue('candidate_country');
        $resume->candidate_zip_code = $this->getFieldValue('candidate_state',"");
        $resume->candidate_state = $this->getFieldValue('candidate_zip_code'."");
        $resume->candidate_location = $this->getFieldValue('candidate_location',"");
        $resume->is_public = wpjb_conf("cv_is_public", 1);
        $resume->is_active = $active;
        $resume->save();
        
        apply_filters("wpjr_form_save_register", $this);
        
        return $resume->id;
    }
    
    public function getId()
    {
        return null;
    }

}

?>