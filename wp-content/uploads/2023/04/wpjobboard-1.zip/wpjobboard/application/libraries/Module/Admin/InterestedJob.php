<?php
/**
 * Description of Payment
 *
 * @author greg
 * @package
 */

class Wpjb_Module_Admin_InterestedJob extends Wpjb_Controller_Admin
{
    public function init()
    {
        $this->_virtual = array(
            "redirectAction" => array(
                "accept" => array("query"),
                "object" => "interestedJob"
            ),
            "deleteAction" => array(
                "info" => __("Alert #%d deleted.", "wpjobboard"),
                "page" => "interestedJob"
            ),
            "_multiDelete" => array(
                "model" => "Wpjb_Model_InterestedJob"
            ),
            "_multi" => array(
                "delete" => array(
                    "success" => __("Number of deleted items: {success}", "wpjobboard")
                )
            )
        );
    }

    public function indexAction()
    {
        global $wpdb;
        
        $page = (int)$this->_request->get("p", 1);
        if($page < 1) {
            $page = 1;
        }
        
        $q = $this->_request->get("query");
        $sort = $this->_request->get("sort", "time");
        $order = $this->_request->get("order", "desc");
        
        $this->view->sort = $sort;
        $this->view->order = $order;
        $this->view->query = $q;
        
        $param = array();
        
        if(!empty($q)) {
            $param["query"] = $q;
        }
        
        $param["sort"] = $sort;
        $param["order"] = $order;
       
        $perPage = $this->_getPerPage();
        
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_InterestedJob t")
            ->order(esc_sql("$sort $order"))
            ->limitPage($page, $perPage);

        if($q) {
           
            $query->where("t.email LIKE ?", "%$q%");
        }
        
        $this->view->data = $query->execute();

        $query = new Daq_Db_Query();
        $total = $query->select("COUNT(*) AS total")
            ->from("Wpjb_Model_InterestedJob t")
            ->limit(1);
        
            if($q) {
             
                $query->where("t.email LIKE ?", "%$q%");
            }

        $stat =(object)array();
        $stat->all = $total->fetchColumn();

        $this->view->stat = $stat;
        $this->view->param = $param;
        $this->view->current = $page;
        $this->view->total = ceil($stat->all/$perPage);
    }

    public function turnOffAction(){
        if (isset($_POST['submit'])) {     
            // $upload = wp_upload_bits($_FILES['fileToUpload']['name'], null, file_get_contents($_FILES['fileToUpload']['tmp_name']));
            $doc=file_get_contents($_FILES['fileToUpload']['tmp_name']);

            $line=explode("\n",$doc);
            $success = 0;
            foreach($line as $newline){
               $email = trim($newline);
               $query = new Daq_Db_Query();
               $query->select("*")
                   ->from("Wpjb_Model_InterestedJob t")
                   ->where("t.email LIKE ?",$email);
                $alerts =  $query->execute();
                if(count($alerts)==0) continue;
                
                $success++;
                $alerts[0]->job_interested = 0;
                $alerts[0]->save();
                $resume = new Wpjb_Model_Resume($alerts[0]->resumeid);
                if( !empty($resume) ) {
                    if( !empty($resume->meta->job_email_alert->getValues()) ) {
                      foreach($resume->meta->job_email_alert->getValues() as $v) {
                        $v->value = 0;
                        $v->save();
                      }
                    } else {
                      global $wpdb;
                      $meta_data = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}wpjb_meta WHERE name = 'job_email_alert' AND meta_object='resume'");
                      $wpdb->insert("{$wpdb->prefix}wpjb_meta_value", array(
                        "meta_id" => $meta_data->id,
                        "object_id" => $resume->id,
                        "value" =>0,
                      ));
                    }
                  }
            }
            $this->_addInfo(__('Number of unsubcribe alerts: '.$success, "wpjobboard"));    
          }
        wp_redirect(wpjb_admin_url("interestedJob"));
        exit();
    }
}