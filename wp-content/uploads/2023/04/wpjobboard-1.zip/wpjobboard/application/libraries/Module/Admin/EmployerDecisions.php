<?php
/**
 * Description of Payment
 *
 * @author greg
 * @package
 */

class Wpjb_Module_Admin_EmployerDecisions extends Wpjb_Controller_Admin
{
    public function init()
    {
        $this->_virtual = array(
            "redirectAction" => array(
                "accept" => array("query"),
                "object" => "employerDecisions"
            )
        );
    }

    public function indexAction()
    {
        global $wpdb;
        
        $page = (int)$this->_request->get("p", 1);
        if($page < 1) {
            $page = 1;
        }
        
        $q = $this->_request->get("query");
        $sort = $this->_request->get("sort", "created_at");
        $order = $this->_request->get("order", "desc");
        
        $this->view->sort = $sort;
        $this->view->order = $order;
        $this->view->query = $q;
        
        $param = array();
        
        if(!empty($q)) {
            $param["query"] = $q;
        }
        
        $param["sort"] = $sort;
        $param["order"] = $order;
       
        $perPage = $this->_getPerPage();
        
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_EmployerDecision t")
            ->order(esc_sql("$sort $order"))
            ->limitPage($page, $perPage);

        if($q) {
            $query->where("job_title LIKE ?", "%$q%");
        }
        
        $this->view->data = $query->execute();

        $query = new Daq_Db_Query();
        $total = $query->select("COUNT(*) AS total")
            ->from("Wpjb_Model_EmployerDecision t")
            ->limit(1);
        
        if($q) {
            $total->where("job_title LIKE ?", "%$q%");
        }

        $stat =(object)array();
        $stat->all = $total->fetchColumn();

        $this->view->stat = $stat;
        $this->view->param = $param;
        $this->view->current = $page;
        $this->view->total = ceil($stat->all/$perPage);
    }
}