<?php

class Wpjb_Module_Admin_VipResumes extends Wpjb_Controller_Admin
{
    public function init()
    {
        $this->_virtual = array(
            "redirectAction" => array(
                "accept" => array("query"),
                "object" => "vipResumes"
            ),
            "deleteAction" => array(
                "info" => __("vip resume #%d deleted.", "wpjobboard"),
                "page" => "vipResumes"
            ),
            "addAction" => array(
                "form" => "Wpjb_Form_Admin_VipResume",
                "info" => __("New vip ressume has been created.", "wpjobboard"),
                "error" => __("There are errors in your form.", "wpjobboard"),
                "url" => wpjb_admin_url("vipResumes", "add", "%d")
            ),
            "editAction" => array(
                "form" => "Wpjb_Form_Admin_VipResume",
                "info" => __("Membership data updated.", "wpjobboard"),
                "error" => __("There are errors in your form.", "wpjobboard")
            ),
            "_multiDelete" => array(
                "model" => "Wpjb_Model_VipResumes"
            ),
            "_multi" => array(
                "delete" => array(
                    "success" => __("Number of deleted vip resumes: {success}", "wpjobboard")
                )
            )
        );
    }

    public function indexAction()
    {
        global $wpdb;       
        
        $page = (int)$this->_request->get("p", 1);
        if($page < 1) {
            $page = 1;
        }
        
        $email = $this->_request->get("query");
        $package_name = $this->_request->get("package_name");
        $payment_type_id = $this->_request->get("payment_type_id");
        $sort = $this->_request->get("sort", "started");
        $order = $this->_request->get("order", "desc");
        
        $this->view->query = $email;
        $this->view->sort = $sort;
        $this->view->order = $order;
        $this->view->package_name = $package_name;
        $this->view->payment_type_id = $payment_type_id;
       
        $perPage = $this->_getPerPage();
        
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_VipResumes t")
            ->order(esc_sql("$sort $order"))
            ->limitPage($page, $perPage);

        if($email) {
            $query->where("t.resume_email LIKE ?", "%$email%");
        }

        if($payment_type_id){
            $query->where("t.payment_type_id = ?", esc_html($payment_type_id));
        }

        if($package_name){
            $query->where("t.package_name LIKE ?", esc_html($package_name));
        }
        
        $this->view->data = $query->execute();

        $query = new Daq_Db_Query();
        $total = $query->select("COUNT(*) AS total")
            ->from("Wpjb_Model_VipResumes t")
            ->limit(1);
        
        if($email) {
            $query->where("t.resume_email LIKE ?", "%$email%");
        }

        if($payment_type_id){
            $query->where("t.payment_type_id = ?", esc_html($payment_type_id));
        }

        if($package_id){
            $query->where("t.package_id = ?", esc_html($payment_type_id));
        }

        $all = $total->fetchColumn();

        $this->view->current = $page;
        $this->view->total = ceil($all/$perPage);
    }

    public function decisionAction(){
        $id = $this->_request->getParam("id");
        $decision = $this->_request->getParam("decision");
        try {
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_VipResumes t")
                ->where("t.id = ?", $id)
                ->limit(1);
            $results = $query->execute();
            if(empty($results)) wp_redirect(wpjb_admin_url("vipResumes"));
            $results[0] -> status = intval($decision);
            $results[0]->save();

            $active_vip = false;
            if($decision == 2){
                $vip_option = 1;    
                $vip_level = 2;  
                $active_vip = true;
            }
            else{
                $vip_option = 0;   
                $vip_level = 0;
            }
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_VipResumes t")
                ->where("t.resume_email LIKE ?",  $results[0]->resume_email)
                ->where("t.status = ?", 2)
                ->limit(1);
            $active_vip_resumes = $query->execute();
            if(empty($active_vip_resumes) || $active_vip){
                global $wpdb;
                $exist_data = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}wpjb_resume WHERE id = {$results[0]->resume_id}");
                if(!empty($exist_data->id)) {
                    $wpdb->update("{$wpdb->prefix}wpjb_resume", array(
                        "vip_option" => $vip_option,
                        "vip_level" => $vip_level
                    ), array(
                        "id" => $exist_data->id
                    ));
                }   
            }                
  
            wp_redirect(wpjb_admin_url("vipResumes"));
        } catch(Exception $e) {
            $this->_addError($e->getMessage());
            // @todo: logging
        }
    }
    
    protected function _multiDelete($id)
    {

        try {
            $model = new Wpjb_Model_VipResumes($id);
            $resume_email = $model->resume_email;
            $resume_id = $model->resume_id;
            $model->delete();
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_VipResumes t")
                ->where("t.resume_email LIKE ?",  $resume_email)
                ->where("t.status = ?", 2)
                ->limit(1);
            $active_vip_resumes = $query->execute();
            if(empty($active_vip_resumes)){
                global $wpdb;
                $exist_data = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}wpjb_resume WHERE id = {$resume_id}");
                if(!empty($exist_data->id)) {
                    $wpdb->update("{$wpdb->prefix}wpjb_resume", array(
                        "vip_option" => 0,
                        "vip_level" => 0
                    ), array(
                        "id" => $exist_data->id
                    ));
                }  
            }
            return true;
        } catch(Exception $e) {
            // log error
            return false;
        }
    }
}