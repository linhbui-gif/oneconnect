<?php
/**
 * Description of Alert
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_InterestedJob extends Daq_Db_OrmAbstract
{
    protected $_name = "custom_alerts_job";

    protected function _init()
    {
        
    }
}

?>