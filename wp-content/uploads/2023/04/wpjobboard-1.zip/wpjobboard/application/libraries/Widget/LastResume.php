<?php

/**
 * Description of Recent Jobs
 *
 * @author greg
 * @package
 */
class Wpjb_Widget_LastResume extends Daq_Widget_Abstract{
	
	public function __construct(){
		$this->_context   = Wpjb_Project::getInstance();
		$this->_viewAdmin = "last-resume.php";
		$this->_viewFront = "last-resume.php";
		
		$this->_defaults["count"] = 5;
		
		parent::__construct(
			"wpjb-last-resume",
			__("Last Resume","wpjobboard"),
			array("description" => __("Displays list of recent resume.","wpjobboard"))
		);
	}
	
	public function update($new_instance,$old_instance){
		$instance          = $old_instance;
		$instance['title'] = htmlspecialchars($new_instance['title']);
		//$instance['hide']  = (int) ($new_instance['hide']);
		$instance['count'] = (int) ($new_instance['count']);
		
		return $instance;
	}
	
	public function _filter(){
		
		$this->view->resumeList = wpjb_find_resumes(array(
			"filter"      => "active",
			//"is_featured" => 1,
			//"sort_order" => "t1.modified_at DESC, t1.id DESC",
			"page"        => 1,
			"count"       => $this->_get("count",$this->_defaults["count"]),
			'search_empty_phone' => false
		))->resume;
		
		//foreach($this->view->resumeList as $resume){
		//	var_dump($resume->getAvatarUrl());
		//}
		//
		//
		////var_dump($this->view->resumeList);
		//die();
	}
	
}