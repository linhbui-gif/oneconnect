<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Membership
 *
 * @author Grzegorz
 */
class Wpjb_Form_Admin_EmployerRate extends Daq_Form_ObjectAbstract
{
    protected $_model = "Wpjb_Model_EmployerRate";
    
    protected $_employerRate = null;
    
    public function getVipResume()
    {
        return $this->_employerRate;
    }
    
    public function init() 
    {
        $this->addGroup("default");

    }
    
    
}
?>
