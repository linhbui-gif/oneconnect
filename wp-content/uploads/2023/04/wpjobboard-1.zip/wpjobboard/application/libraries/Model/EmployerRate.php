<?php
/**
 * Description of Alert
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_EmployerRate extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_employer_rate";

    protected function _init()
    {
        
    }
}

?>