<?php
/**
 * Description of Payment
 *
 * @author greg
 * @package
 */

class Wpjb_Module_Admin_AlertStats extends Wpjb_Controller_Admin
{
    public function init()
    {
        $this->_virtual = array(
            "redirectAction" => array(
                "accept" => array("query"),
                "object" => "alertStats"
            ),
            "deleteAction" => array(
                "info" => __("Alert #%d deleted.", "wpjobboard"),
                "page" => "alertStats"
            ),
            "_multiDelete" => array(
                "model" => "Wpjb_Model_AlertStat"
            ),
            "_multi" => array(
                "delete" => array(
                    "success" => __("Number of deleted items: {success}", "wpjobboard")
                )
            )
        );
    }

    public function indexAction()
    {
        global $wpdb;
        
        $stat = (object)array("all"=>0, "job_alerts"=>0, "interested_jobs"=>0);
        
        $page = (int)$this->_request->get("p", 1);
        if($page < 1) {
            $page = 1;
        }
        
        $q = $this->_request->get("query");
        $campaign = $this->_request->get("campaign","all");
        $sort = $this->_request->get("sort", "sent_at");
        $order = $this->_request->get("order", "desc");
        
        $this->view->sort = $sort;
        $this->view->order = $order;
        $this->view->query = $q;
        
        $param = array();
        
        if(!empty($q)) {
            $param["query"] = $q;
        }
        
        $param["sort"] = $sort;
        $param["order"] = $order;
       
        $perPage = $this->_getPerPage();
        
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_AlertStat t")
            ->order(esc_sql("$sort $order"))
            ->limitPage($page, $perPage);

        if($q) {
            $query->where("email LIKE ?", "%$q%");
        }
        if($campaign && $campaign !='all') {
            $query->where("campaign LIKE ?", esc_html($campaign));
        } 
        
        $this->view->data = $query->execute();

        $query = new Daq_Db_Query();
        $total = $query->select("COUNT(*) AS total")
            ->from("Wpjb_Model_AlertStat t")
            ->limit(1);
        
        if($q) {
            $total->where("email LIKE ?", "%$q%");
        }

        $stat->all = $total->fetchColumn();
        $job_alerts = clone $total;
        $stat->job_alerts = $job_alerts->where("campaign LIkE \"job alert\"")->fetchColumn();
        $interested_jobs = clone $total;
        $stat->interested_jobs = $interested_jobs->where("campaign LIkE \"interested job\"")->fetchColumn();

        $this->view->campaign = $campaign;
        $this->view->stat = $stat;
        $this->view->param = $param;
        $this->view->current = $page;
        $this->view->total = ceil($stat->all/$perPage);
    }
    
}

?>