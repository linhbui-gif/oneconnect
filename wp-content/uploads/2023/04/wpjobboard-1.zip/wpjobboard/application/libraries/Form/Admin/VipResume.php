<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Membership
 *
 * @author Grzegorz
 */
class Wpjb_Form_Admin_VipResume extends Daq_Form_ObjectAbstract
{
    protected $_model = "Wpjb_Model_VipResumes";
    
    protected $_vipResume = null;
    
    public function getVipResume()
    {
        return $this->_vipResume;
    }
    
    public function init() 
    {
        $this->addGroup("default");

        if($this->getObject()->resume_id > 0) {
            $resume_id = $this->getObject()->resume_id;
            $resume_email = $this->getObject()->resume_email;
            $user_id = get_user_by("email", $this->getObject()->resume_email)->ID;
        } else {
            $resume_id = 0;
            $user_id = 0;
            $resume_email = __("None", "wpjobboard");
        }
        
        $e = $this->create("resume_email", "text");
        $e->setLabel(__("Email", "wpjobboard"));
        $e->setValue($resume_email);
        $this->addElement($e, "default");
        
        $vip_packages = get_field('package_options', 'option');
        
        $e = $this->create("package_id", "select");
        $e->setValue($this->getObject()->package_id);
        $e->setLabel(__("Package", "wpjobboard"));
        foreach($vip_packages as $package){
                $price = $package['price'];
                $duration = $package['package_duration'];
                $package_name = $package['package_name'];
                $e->addOption($package['id'], $package['id'], $package_name);
        }
        $this->addElement($e, "default");

        $e = $this->create("payment_type_id", "select");
        $e->setValue($this->getObject()->payment_type_id);
        $e->setLabel(__("Payment Type", "wpjobboard"));
        $e->addOption('0', '0', 'Bank');
        $e->addOption('1', '1', 'Paypal');
        $this->addElement($e, "default");
        
        $e = $this->create("started", "text_date");
        $e->setDateFormat(wpjb_date_format());
        $e->setValue($this->ifNew(date("Y-m-d"), $this->getObject()->started));
        $e->setLabel(__("Started At", "wpjobboard"));
        $this->addElement($e, "default");
        
        $t = wpjb_time("today +30 day");
        $e = $this->create("expires", "text_date");
        $e->setDateFormat(wpjb_date_format());
        $e->setValue($this->ifNew(date("Y-m-d", $t), $this->getObject()->expires));
        $e->setLabel(__("Expires At", "wpjobboard"));
        $this->addElement($e, "default");   

        $e = $this->create("status", "select");
        $e->setValue($this->getObject()->status);
        $e->setLabel(__("Status", "wpjobboard"));
        $e->addOption(Wpjb_Model_VipResumes::ACTIVE_STATUS, Wpjb_Model_VipResumes::ACTIVE_STATUS, 'Active');
        $e->addOption(Wpjb_Model_VipResumes::WAITING_STATUS, Wpjb_Model_VipResumes::WAITING_STATUS, 'Awaiting');
        $e->addOption(Wpjb_Model_VipResumes::DISABLE_STATUS, Wpjb_Model_VipResumes::DISABLE_STATUS, 'Disable');
        $this->addElement($e, "default");
        
        wp_enqueue_script("wpjb-vendor-datepicker");
        wp_enqueue_style("wpjb-vendor-datepicker");
    }
    
    public function save($append = array())
    {
        parent::save($append);
        
        $object = $this->getObject();
        
        $resume_email = $object->resume_email;
        $user = get_user_by('email',$resume_email);
        if(!empty($user)){
            $id = $user->ID;
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_Resume t")
                ->where("t.user_id = ?", $id)
                ->limit(1);
            $results = $query->execute();
            if(!empty($results)){
                $object->resume_id = $results[0]->id;
                $active_vip = false;
                if($object->status == Wpjb_Model_VipResumes::ACTIVE_STATUS){
                    $vip_option = 1;    
                    $vip_level = 2;  
                    $active_vip = true;
                }
                else{
                    $vip_option = 0;   
                    $vip_level = 0;
                }
                $query = new Daq_Db_Query();
                $query->select("*")
                    ->from("Wpjb_Model_VipResumes t")
                    ->where("t.resume_email LIKE ?",  $resume_email)
                    ->where("t.status = ?", 2)
                    ->limit(1);
                $active_vip_resumes = $query->execute();
                if(empty($active_vip_resumes) || $active_vip){
                    global $wpdb;
                    $wpdb->update("{$wpdb->prefix}wpjb_resume", array(
                        "vip_option" => $vip_option,
                        "vip_level" => $vip_level
                    ), array(
                        "id" => $results[0]->id
                    ));
                    if(empty($object->order_code)){
                        $object->order_code = uniqid();
                    }
                }          
            }
        }
        switch($object->payment_type_id){
            case 0:
                $object->payment_type_name = 'Bank';
                break;
            case 1:
                $object->payment_type_name = 'Paypal';
                break;
        }
        $vip_packages = get_field('package_options', 'option');
        foreach($vip_packages as $package){
            if($package['id']==$object->package_id){
                $package_name = $package['package_name'];
                $object->package_name = $package_name;
                break;
            }
        }
        $object->save();
         
    }
}
?>
