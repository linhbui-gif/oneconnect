<?php
/**
 * Description of Alert
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_EmployerDecision extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_employer_decision_notification";

    protected function _init()
    {
        
    }
}

?>