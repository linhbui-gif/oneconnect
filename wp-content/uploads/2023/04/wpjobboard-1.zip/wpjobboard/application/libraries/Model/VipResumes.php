<?php
/**
 * Description of Vip resume
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_VipResumes extends Daq_Db_OrmAbstract
{
    const WAITING_STATUS = 0;
    const EXPIRED_STATUS = 1;
    const ACTIVE_STATUS = 2;
    CONST DISABLE_STATUS = 3;
    protected $_name = "wpjb_vip_resumes";

    protected function _init()
    {
        
    }
}

?>