<?php
/**
 * Description of ${name}
 *
 * @author ${user}
 * @package 
 */

class Wpjb_Model_ResumesAccess extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_resumes_access";

    protected function _init()
    {

    }
    

    
}

?>
