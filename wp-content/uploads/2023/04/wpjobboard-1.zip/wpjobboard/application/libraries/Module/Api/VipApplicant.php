<?php
class Wpjb_Module_Api_VipApplicant extends Daq_Controller_Abstract
{
    public function getRequest()
    {
        return Daq_Request::getInstance();
    }

    public function paypalIPNAction()
    {
        error_log('paypalIPNAction');
        if(!$this->validatePaymentResponse()) {
             error_log('Invalid IPNn');
            wp_die(__("<strong>ERROR</strong> Error while processing paypal payment", "wpjobboard"), __("VipApplicant", "wpjobboard"));
        }
        error_log('vaid IPN');
        $item_name = $_POST['item_name'];
        $item_number = $_POST['item_number'];
        $payment_status = $_POST['payment_status'];
        $payment_amount = $_POST['mc_gross'];
        $payment_currency = $_POST['mc_currency'];
        $txn_id = $_POST['txn_id'];
        $receiver_email = $_POST['receiver_email'];
        $payer_email = $_POST['payer_email'];
        $package_id = $this->getRequest()->getParam("package_id");
        $resume_id = $this->getRequest()->getParam("resume_id");
        $query = new Daq_Db_Query();
        $select = $query->select()
            ->from("Wpjb_Model_Resume t1")
            ->where("t1.id = ?", intval($resume_id))
            ->limit(1);
        $resumes = $select->execute();
        if(empty($resumes)){
            wp_die(__("<strong>ERROR</strong>Invalid resume", "wpjobboard"), __("VipApplicant", "wpjobboard"));
        }
        $vip_resume = $this->create_vip_resume($package_id, $resumes[0], $txn_id, 1);  
        $this->update_resume_vip_state($resumes[0]->id);
        $vip_packages = get_field('package_options', 'option');
        foreach($vip_packages as $package){
            if($package['id']==$package_id){
                $price = $package['price'];
                $duration = $package['package_duration'];
                $package_name = $package['package_name'];
                break;
            }
        }
        //send email to admin
        $mail = Wpjb_Utility_Message::load("notify_vip_resume_paypal");
        $mail->assign("resume_email", $resumes[0]->getUser(true)->user_email);
        $mail->assign("id", $resume_id);
        $mail->assign("package_name", $package_name);
        $mail->assign("package_price", '$'.$price);   
        $mail->setTo(get_option('admin_email'));
        $mail->send();

        //send email to resume
        $mail = Wpjb_Utility_Message::load("notify_vip_resume_paypal_successful");
        $mail->assign("current_time", date("Y-m-d H:i:s"));
        $mail->assign("resume_email", $resumes[0]->getUser(true)->user_email);
        $mail->assign("resume_name", $resumes[0]->getUser(true)->display_name);
        $mail->assign("package_name", $package_name);
        $mail->assign("duration", $duration);
        $mail->assign("price", '$'.$price);   
        $mail->assign("start_date", $vip_resume->started);   
        $mail->assign("end_date", $vip_resume->expires);   
        $mail->setTo($resumes[0]->getUser(true)->user_email);
        $mail->send();
    }

    private function update_resume_vip_state($resume_id){
        global $wpdb;
        $wpdb->update("{$wpdb->prefix}wpjb_resume", array(
            "vip_option" => 1,
            "vip_level" => 2
        ), array(
            "id" => $resume_id
        ));
    }

    private function create_vip_resume($package_id, $resume, $order_code, $payment_type_id){
        $vip_packages = get_field('package_options', 'option');
        foreach($vip_packages as $package){
            if($package['id']==$package_id){
                $price = $package['price'];
                $duration = $package['package_duration'];
                $package_name = $package['package_name'];
                break;
            }
        }
        if(!isset($price) || !isset($duration)){
            wp_die(__("<strong>ERROR</strong>Invalid package", "wpjobboard"), __("VipApplicant", "wpjobboard"));
        }
        $resume_email = $resume->getUser(true)->user_email;
        $start_date = date("Y-m-d H:i:s");
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_VipResumes t")
            ->where("t.resume_email = ?", $resume_email)
            ->where("t.status =?", 2)
            ->order("t.expires DESC")
            ->limit(1);
        $vip_resumes = $query->execute();
        if(count($vip_resumes)>0){
            $start_date = $vip_resumes[0]->expires;
        }
        $duration_num = explode(" ", $duration);
        $ex_time = '+'.$duration_num[0].' months';
        if (strpos($duration, 'weeks') !== false) {
            $ex_time = '+'.$duration_num[0].' weeks';           
        } elseif( strpos($duration, 'months') !== false ) {
            $ex_time = '+'.$duration_num[0].' months';
        }
        $expires = date("Y-m-d H:i:s", strtotime($ex_time, strtotime($start_date)));

        $vip_resume = new Wpjb_Model_VipResumes();
        $vip_resume->resume_id = $resume->id;
        $vip_resume->resume_email = $resume_email;
        $vip_resume->package_name = $package_name;
        $vip_resume->package_id = $package_id;
        $vip_resume->started = $start_date;
        $vip_resume->expires = $expires;      
        $vip_resume->order_code = $order_code;
        $vip_resume->payment_type_id = $payment_type_id;
        $vip_resume->status = 2;
        if($payment_type_id == 1){
            $vip_resume->payment_type_name = 'Paypal';
        }
        elseif($payment_type_id == 0){
            $vip_resume->payment_type_name = 'Bank';
        }
        $vip_resume->save();
         return $vip_resume;
    }

    public function bankTransferConfirmAction(){
        $token = $this->getRequest()->getParam("token");
        $order_code = $this->getRequest()->getParam("order_code");
        $package_id = $this->getRequest()->getParam("package_id");
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_VipResumes t")
            ->where("t.order_code = ?", $order_code)
            ->limit(1);
        $vip_resumes = $query->execute();
        if(count($vip_resumes)>0){
            wp_die(__("<strong>ERROR</strong> Order code has already existed.", "wpjobboard"), __("VipApplicant", "wpjobboard"));
        }
        $query = new Daq_Db_Query();
        $query->from("Wpjb_Model_Resume t");
        $query->where("MD5(CONCAT(t.id, '|', t.user_id)) = ?", $token);
        $query->limit(1);
        $resumes = $query->execute();
        if(empty($resumes)){
            wp_die(__("<strong>ERROR</strong> Invalid Token.", "wpjobboard"), __("VipApplicant", "wpjobboard"));
        }
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_VipResumes t")
            ->where("t.resume_email = ?", $resumes[0]->getUser(true)->user_email)
            ->where("t.status =?", 2)
            ->order("t.expires DESC")
            ->limit(1);
        $vip_resumes = $query->execute();
        $existed_vip = false;
        if(count($vip_resumes)>0){
            $existed_vip = true;
        }
        $vip_resume = $this->create_vip_resume($package_id, $resumes[0], $order_code, 0);
        $this->update_resume_vip_state($resumes[0]->id);

        $vip_packages = get_field('package_options', 'option');
        foreach($vip_packages as $package){
            if($package['id']==$package_id){
                $price = $package['price'];
                $duration = $package['package_duration'];
                $package_name = $package['package_name'];
                break;
            }
        }
        //send email to resume
        $mail = Wpjb_Utility_Message::load("notify_vip_resume_bank_successful");
        $mail->assign("current_time", date("Y-m-d H:i:s"));
        $mail->assign("resume_email", $resumes[0]->getUser(true)->user_email);
        $mail->assign("resume_name", $resumes[0]->getUser(true)->display_name);
        $mail->assign("package_name", $package_name);
        $mail->assign("duration", $duration);
        $mail->assign("price", '$'.$price);   
        $mail->assign("start_date", $vip_resume->started);   
        $mail->assign("end_date", $vip_resume->expires);   
        $mail->setTo($resumes[0]->getUser(true)->user_email);
        $mail->send();
        wp_die(__("<strong>SUCCESS</strong> Activate VIP Resume successfully", "wpjobboard"), __("VipApplicant", "wpjobboard"));
    }

    private function validatePaymentResponse(){
        $raw_post_data = file_get_contents('php://input');
        if(!$raw_post_data) return false;
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode ('=', $keyval);
            if (count($keyval) == 2)
                $myPost[$keyval[0]] = urldecode($keyval[1]);
        }
        // read the post from PayPal system and add 'cmd'
        $req = 'cmd=_notify-validate';
        if(function_exists('get_magic_quotes_gpc')) {
            $get_magic_quotes_exists = true;
        }
        foreach ($_POST as $key => $value) {
            $value = urlencode(stripslashes($value));
            $value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i', '${1}%0D%0A${3}', $value); // IPN fix
            $req .= "&$key=$value";
        }
        // Post IPN data back to PayPal to validate the IPN data is genuine
        // Without this step anyone can fake IPN data
        
        //$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
    
        $paypal_url = "https://www.paypal.com/cgi-bin/webscr";
        
        $ch = curl_init($paypal_url);
        if ($ch == FALSE) {
            return FALSE;
        }
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);

        // CONFIG: Optional proxy configuration
        //curl_setopt($ch, CURLOPT_PROXY, $proxy);
        //curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
        // Set TCP timeout to 30 seconds
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close', 'User-Agent: PHP-IPN-Verification-Script'));
        // CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
        // of the certificate as shown below. Ensure the file is readable by the webserver.
        // This is mandatory for some environments.
        //$cert = __DIR__ . "./cacert.pem";
        //curl_setopt($ch, CURLOPT_CAINFO, $cert);
        $res = curl_exec($ch);
        if (curl_errno($ch) != 0) // cURL error
            {
            
            curl_close($ch);
            exit;
        } else {
                
            curl_close($ch);
        }
        // Inspect IPN validation result and act accordingly
        // Split response headers and payload, a better way for strcmp
        $tokens = explode("\r\n\r\n", trim($res));
        $res = trim(end($tokens));
        if (strcmp ($res, "VERIFIED") == 0) return true;
        return false;
    }
}