<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PricingException
 *
 * @author Grzegorz
 */
class Wpjb_Model_PricingException extends Exception 
{
    //put your code here
}

?>
