<?php
/**
 * Description of EmployerRate
 *
 * @author greg
 * @package
 */

class Wpjb_Module_Admin_EmployerRate extends Wpjb_Controller_Admin
{
    public function init()
    {
        $this->_virtual = array(
            "redirectAction" => array(
                "accept" => array("query"),
                "object" => "employerRate"
            ),
            "deleteAction" => array(
                "info" => __("Item #%d deleted.", "wpjobboard"),
                "page" => "employerRate"
            ),
            "editAction" => array(

            ),
            "_multiDelete" => array(
                "model" => "Wpjb_Model_EmployerRate"
            ),
            "_multi" => array(
                "delete" => array(
                    "success" => __("Number of deleted items: {success}", "wpjobboard")
                )
            )
        );
    }
    public function indexAction()
    {
        global $wpdb;
        
        $stat = (object)array("all"=>0,"waiting"=>0, "reject"=>0, "approve"=>0);
        
        $page = (int)$this->_request->get("p", 1);
        if($page < 1) {
            $page = 1;
        }
        
        $q = $this->_request->get("query");
        $sort = $this->_request->get("sort", "updated_at");
        $order = $this->_request->get("order", "desc");
        $filter = $this->_request->get("filter", "all");

        $this->view->sort = $sort;
        $this->view->order = $order;
        $this->view->query = $q;
        $this->view->filter = $filter;
        
        $param = array();
        
        if(!empty($q)) {
            $param["query"] = $q;
        }
        
        $param["sort"] = $sort;
        $param["order"] = $order;
       
        $perPage = $this->_getPerPage();
        
        $query = new Daq_Db_Query();
        $query->select("*")
            ->from("Wpjb_Model_EmployerRate t")
            ->order(esc_sql("$sort $order"))
            ->limitPage($page, $perPage);

        if($q) {
            $query->where("company_name LIKE ?", "%$q%");
        }
        
        $this->view->data = $query->execute();

        $query = new Daq_Db_Query();
        $total = $query->select("COUNT(*) AS total")
            ->from("Wpjb_Model_EmployerRate t")
            ->limit(1);
        
        if($q) {
            $total->where("company_name LIKE ?", "%$q%");
        }

        $stat->all = $total->fetchColumn();
        $waiting = clone $total;
        $stat->waiting = $waiting->where("status = 0")->fetchColumn();
        $approve = clone $total;
        $stat->approve = $approve->where("status = 2")->fetchColumn();
        $reject = clone $total;
        $stat->reject = $reject->where("status = 1")->fetchColumn();

        $this->view->stat = $stat;
        $this->view->param = $param;
        $this->view->current = $page;
        $this->view->total = ceil($stat->all/$perPage);
    }

    public function decisionAction(){
        $id = $this->_request->getParam("id");
        $decision = $this->_request->getParam("decision");
        try {
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_EmployerRate t")
                ->where("t.id = ?", $id)
                ->limit(1);
            $results = $query->execute();
            if(empty($results)) wp_redirect(wpjb_admin_url("employerRate"));
            $results[0] -> status = intval($decision);
            $results[0] -> updated_at = current_time("mysql");
            $results[0]->save();
            $query = new Daq_Db_Query();
            $query->from("Wpjb_Model_Resume t");
            $query->where("t.id = ?", $results[0]->resume_id);;
            $query->limit(1);
            $resumes = $query->execute();
            if(empty($resumes)){
                wp_redirect(wpjb_admin_url("employerRate"));
            }
            $query = new Daq_Db_Query();
            $query->from("Wpjb_Model_Company t");
            $query->where("t.id = ?", $results[0]->employer_id);;
            $query->limit(1);   
            $employers = $query->execute();
            if($decision == 2){
                ///send email to reviewer
                $mail = Wpjb_Utility_Message::load("notify_resume_review_approved");
                $mail->assign("company", $employers[0] -> company_name); 
                $mail->assign("company_review_url", wpjb_link_to("company_reviews", $employers[0])); 
                $mail->setTo($resumes[0] ->getUser(true)->user_email);
                $mail->send();
                
                $mail = Wpjb_Utility_Message::load("notify_company_new_review");
                $mail->assign("company_review_url", wpjb_link_to("company_manage_review", $employers[0])); 
                $mail->setTo($employers[0]->getUsers(true)->user_email);
                //$mail->send();
            }

            if($decision == 1){
                ///send email to reviewer
                $mail = Wpjb_Utility_Message::load("notify_resume_review_rejected");
                $mail->assign("company", $employers[0] -> company_name); 
                $mail->setTo($resumes[0] ->getUser(true)->user_email);
                $mail->send();
            }
            wp_redirect(wpjb_admin_url("employerRate"));
        } catch(Exception $e) {
            $this->_addError($e->getMessage());
            // @todo: logging
        }
    }

    public function visibilityAction(){
        $id = $this->_request->getParam("id");
        $visibility = $this->_request->getParam("visibility");
        try {
            $query = new Daq_Db_Query();
            $query->select("*")
                ->from("Wpjb_Model_EmployerRate t")
                ->where("t.id = ?", $id)
                ->limit(1);
            $results = $query->execute();
            if(empty($results)) wp_redirect(wpjb_admin_url("employerRate"));
            $results[0] -> show_review = intval($visibility);
            $results[0]->save();
            wp_redirect(wpjb_admin_url("employerRate"));
        } catch(Exception $e) {
            $this->_addError($e->getMessage());
            // @todo: logging
        }
    }


}