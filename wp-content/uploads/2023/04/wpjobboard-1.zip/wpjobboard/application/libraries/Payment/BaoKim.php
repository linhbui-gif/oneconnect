<?php
/*
 * lwdpt_1228422945_per@jadamspam.pl
 */

/**
 * Description of PayPal
 *
 * @author greg
 */
class Wpjb_Payment_BaoKim extends Wpjb_Payment_Abstract{
	const ENV_SANDBOX    = 1;
	const ENV_PRODUCTION = 2;
	
	
	const DEFAULT_KEY = '-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDZZBAIQz1UZtVm
p0Jwv0SnoIkGYdHUs7vzdfXYBs1wvznuLp/SfC/MHzHVQw7urN8qv+ZDxzTMgu2Q
3FhMOQ+LIoqYNnklm+5EFsE8hz01sZzg+uRBbyNEdcTa39I4X88OFr13KoJC6sBE
397+5HG1HPjip8a83v8G4/IPcna5/3ydVbJ9ZeMSUXP6ZyKAKay4M22/Wli7PLrm
1XNR9JgIuQLma74yCGkaXtCJQswjyYAmwDPpz4ZknSGuBYUmwaHMgrDOQsOXFW7/
7M2KbjenwggAW98f0f97AR2DEq9Eb5r8vzyHURnHGD3/noZxl993lM2foPI3SKBO
1KpSeXRzAgMBAAECggEANMINBgRTgQVH6xbSkAxLPCdAufTJeMZ56bcKB/h2qVMv
Wvejv/B1pSM489nHaPM5YeWam35f+PYZc5uWLkF23TxvyEsIEbGLHKktEmR73WkS
eqNI+/xd4cJ3GOtS2G2gEXpBVwdQ/657JPvz4YZNdjfmyxMOr02rNN/jIg6Uc8Tz
vbpGdtP49nhqcOUpbKEyUxdDo6TgLVgmLAKkGJVW40kwvU9hTTo6GXledLNtL2kD
l6gpVWAiT6xlTsD5m74YzsxCSjkh60NdYeUDYwMbv0WWH3kJq6qD063ac3i/i8H+
B5nGf4KbKg1bBjPLNymUj7RRnKjHr301i2u8LUQYuQKBgQD15YCoa5uHd6DHUXEK
kejU34Axznr3Gs6LqcisE7t0oQ9hB4s16U9f4DBHDOvnkLb0zkadwdEmwo/D/Tdf
5c/JEk8q/aO9Wk8uV4Bswnx1OV9uKMzMOZbv/So1DQg1aW1MgvRnj3SiKpDUkNwr
en4NT9tbH21SmVIO9Da5KpiFRwKBgQDiUrg1hp8EDaeZFTG9DvcwyTTrpD/YT9Wr
s/NtEnPMjy0NXWcEXwGzx90P+qjJ+J29Hk89QHON6S7o0X2lUIer3uXokc86ce76
5UIbR6u7R1T6TUNfwqwwNfIbgtFN4+7ybodPNZ5DWslKLqMr5wpwIOr7/U5ih7BH
JK0cSriddQKBgGXzNZiepOlRrBN3rMqZHFPGJrx/w3PYZXJ6fnz54WrFrD6qhglg
Jky2As4yiUyFL5XoQFcAGNtdJ4Y24lKcUb4oHTLR3qWPX+zy0ohFSpy/oNVnjSHP
bskpyeoc8R5UC8EBOpwFWnIx+8JmHSLZspGKXoQ1T3pDn0Yb8uRqyLnZAoGBAKdk
NwqfvwzobIU0v8ztPLbAmnuOyAndQlP0jJ6nfy5U1yWDZ6Y7/q5RrJcc9aosT76I
pGLRQKY9SYy5JQ0YOsBL5A/XiEXZ7r9ywSocIFAruhZG/wXcni4qOB9Q6i2J4Dk+
tqVHKv72LtrHE7hs8bNtJV+rQkZtxVtZLRA308PhAoGBALVEaYMRm97V+Tnsej6q
fuT/6oKHPqZpur2rNfEKVn5Aq2kmFrvyUhvXi0IAWQ/XS3XJ7faQnprrWT6pYiSy
2YQuaghlNG1SATVd5eUadq2pA8DuSzqWFa0Ac1IAyliBO2uLPL7LzuEKmmuQk0vI
TU2Q8idAb77K7mvVguA3LDhN
-----END PRIVATE KEY-----';
	
	const BAOKIM_API_SELLER_INFO = '/payment/rest/payment_pro_api/get_seller_info';
	const BAOKIM_API_PAY_BY_CARD = '/payment/rest/payment_pro_api/pay_by_card';
	const BAOKIM_API_PAYMENT     = '/payment/order/version11';
	
	//Phương thức thanh toán bằng thẻ nội địa
	const PAYMENT_METHOD_TYPE_LOCAL_CARD = 1;
	
	//Phương thức thanh toán bằng thẻ tín dụng quốc tế
	const PAYMENT_METHOD_TYPE_CREDIT_CARD = 2;
	
	//Dịch vụ chuyển khoản online của các ngân hàng
	const PAYMENT_METHOD_TYPE_INTERNET_BANKING = 3;
	
	//Dịch vụ chuyển khoản ATM
	const PAYMENT_METHOD_TYPE_ATM_TRANSFER = 4;
	
	//Dịch vụ chuyển khoản truyền thống giữa các ngân hàng
	const PAYMENT_METHOD_TYPE_BANK_TRANSFER = 5;
	/**
	 * PayPal enviroment
	 *
	 * @var integer one of PayPal::ENV_<ENV>
	 */
	private $_env;
	
	/**
	 * Job object
	 *
	 * @var Wpjb_Model_Job
	 */
	protected $_data = null;
	
	public function __construct(Wpjb_Model_Payment $data = null){
		
		$this->_default = array(
			"baokim_env"         => wpjb_conf("baokim_env",self::ENV_SANDBOX),
			"EMAIL_BUSINESS"     => wpjb_conf("EMAIL_BUSINESS",'dev.baokim@bk.vn'),
			"MERCHANT_ID"        => wpjb_conf("MERCHANT_ID",'647'),
			"SECURE_PASS"        => wpjb_conf("SECURE_PASS",'ae543c080ad91c23'),
			"API_USER"           => wpjb_conf("API_USER",'merchant'),
			"API_PWD"            => wpjb_conf("API_PWD",'1234'),
			"PRIVATE_KEY_BAOKIM" => wpjb_conf("PRIVATE_KEY_BAOKIM",self::DEFAULT_KEY),
		);
		
		$env = $this->conf("baokim_env");
		$this->setEnviroment($env);
		$this->_data = $data;
	}
	
	public function getEngine(){
		return "BaoKim";
	}
	
	public function getTitle(){
		return "Bảo Kim";
	}
	
	public function getForm(){
		return "Wpjb_Form_Admin_Config_BaoKim";
	}
	
	public function setEnviroment($env = self::ENV_PRODUCTION){
		$this->_env = $env;
	}
	
	public function getDomain(){
		if($this->_env == self::ENV_PRODUCTION){
			return "https://www.baokim.vn";
		}else{
			return "http://kiemthu.baokim.vn";
		}
	}
	
	/**
	 * Depending on settings return either sandbox or production URL
	 *
	 * @return string
	 */
	public function getUrl(){
		return $this->getDomain() . "/cgi-bin/webscr";
	}
	
	/**
	 * Returns baokim eMail .
	 *
	 * @return string
	 */
	public function getEmail(){
		return $this->conf("EMAIL_BUSINESS");
	}
	
	public function getMerchantId(){
		return $this->conf("MERCHANT_ID");
	}
	
	
	/**
	 * @return array
	 * @throws \Exception
	 */
	public function processTransaction(){
		$post = $this->_post;
		$get  = $this->_get;
		$path = Wpjb_List_Path::getPath("vendor");
		require_once($path . '/baokim/baokim_payment.php');
		$baokim_payment = new BaoKimPayment();
		
		$data = array(
			'order_id'           => $get['order_id'],
			'transaction_id'     => $get['transaction_id'],
			'created_on'         => $get['created_on'],
			'payment_type'       => $get['payment_type'],
			'transaction_status' => $get['transaction_status'],
			'total_amount'       => $get['total_amount'],
			'net_amount'         => $get['net_amount'],
			'fee_amount'         => $get['fee_amount'],
			'merchant_id'        => $get['merchant_id'],
			'customer_name'      => $get['customer_name'],
			'customer_email'     => $get['customer_email'],
			'customer_phone'     => $get['customer_phone'],
			'customer_address'   => $get['customer_address'],
			'Checksum'           => $get['Checksum'],
		);
		if($baokim_payment->verifyResponseUrl($data)){
			return array(
				"external_id" => $get['transaction_id'],
				"paid"        => $get['total_amount'],
			);
		}
		throw new Exception("Error");
	}
	
	public function render(){
		$arr = array(
			"action" => "wpjb_payment_accept",
			"engine" => $this->getEngine(),
			"id"     => $this->_data->id,
		);
		
		$instance = Wpjb_Project::getInstance();
		
		//var_dump($this->_data);die();
		if($this->_data->object_type == 1){
			$completeUrl = wpjb_link_to("step_complete",$this->_data);
		}elseif($this->_data->object_type == 2 && wpjb_conf("urls_cpt")){
			$completeUrl = get_permalink();
			//}elseif($this->_data->object_type == 2){
			//	//$completeUrl = wpjr_link_to("resume",$this->_data);
			//	$completeUrl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . '?payment_id=' . $this->_data->id;
		}else{
			$completeUrl = wpjb_link_to("step_complete",$this->_data);
		}
		
		$notify   = admin_url('admin-ajax.php') . "?" . http_build_query($arr);
		$complete = $completeUrl;
		$amount   = $this->_data->payment_sum - $this->_data->payment_paid;
		$currency = $this->_data->payment_currency;
		$product  = str_replace("{num}",$this->_data->getId(),__("Job Board order #{num} at: ","wpjobboard"));
		$product .= get_bloginfo("name");
		$path = Wpjb_List_Path::getPath("vendor");
		if(isset($_POST['bank_payment_method_id'])){
			require_once($path . '/baokim/baokim_payment.php');
			$data                 = $_POST;
			$data['total_amount'] = $amount;
			$data['payer_email']  = $this->_data->email;
			$data['url_success']  = $complete;
			$data['url_cancel']   = $complete;
			$data['currency']     = $currency;
			$data['product']      = $product;
			$data['order_id']     = $this->_data->getId();
			$baokim               = new BaoKimPayment();
			$baokim_url           = $baokim->createRequestUrl($data);
			//echo $baokim_url;
			header("Location: " . $baokim_url);
			exit();
		}
		$html = "";
		$html .= '<form action="" method="post">';
		
		$html .= '<div class="method row-fluid" id="2">
					<div class="info">
						<label>Thanh toán trực tuyến bằng thẻ quốc tế 
						<input type="radio" name="bank_payment_method_id" value="2"></label>
					</div>
				</div>';
		//$html .= '<div class="method row-fluid" id="3">
		//			<div class="info">
		//				<label>Chuyển khoản InternetBanking 
		//				<input type="radio" name="bank_payment_method_id" value="3">
		//				</label>
		//			</div>
		//		</div>';
		$html .= '<div class="method row-fluid" id="1">
					<div class="info">
						<label>Thanh toán trực tuyến bằng thẻ ATM nội địa 
						<input type="radio" name="bank_payment_method_id" value="1">
						</label>
					</div>
				</div>';
		//$html .= '<div class="method row-fluid" id="0">
		//			<div class="info">
		//				<label>Thanh toán Bảo Kim
		//				<input type="radio" name="bank_payment_method_id" value="0">
		//				</label>
		//			</div>
		//		</div>';
		
		$html .= '<input type="hidden" name="shipping_address" size="30" value="Hà Nội"/>';
		$html .= '<input type="hidden" name="payer_message" size="30" value="Ok"/>';
		$html .= '<input type="hidden" name="extra_fields_value" size="30" value=""/>';
		$html .= '<input type="hidden" name="extra_payment" id="extra_payment" value=""/>';
		$html .= '<input type="hidden" name="payment_method" value="' . $this->_data->engine . '">';
		$html .= '<input type="hidden" name="email" value="' . $this->_data->email . '">';
		$html .= '<input type="hidden" name="listing" value="' . $_POST['listing'] . '">';
		$html .= '<input type="hidden" name="listing_type" value="' . $_POST['listing_type'] . '">';
		$html .= '<input type="hidden" name="purchase" value="' . $_POST['purchase'] . '">';
		$html .= '<button type="submit"><img src="https://www.baokim.vn/cdn/x_developer/module/baokim_btn/thanhtoan-m.png" /></button>';
		$html .= '</form>';
		
		//$html .= "object_type  : " . $this->_data->object_type . "<br/>";
		//$html .= "Notify URL: " . admin_url('admin-ajax.php') . "?" . http_build_query($arr) . "<br/>";
		// and complete URL that is url when user should be redirected after payment
		//$html .= $complete . "<br/>";
		// and of course amount to pay and currency
		//$html .= "To pay: " . ($this->_data->payment_sum - $this->_data->payment_paid) . " " . $this->_data->payment_currency;
		
		return $html;
	}
	
	public function bind(array $post,array $get){
		$this->setObject(new Wpjb_Model_Payment($get["id"]));
		
		parent::bind($post,$get);
	}
	
	public function getIcon(){
		return "wpjb-icon-bold";
	}
	
}

?>