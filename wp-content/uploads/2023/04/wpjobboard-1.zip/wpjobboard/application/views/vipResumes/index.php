<div class="wrap">
    
<?php $this->_include("header.php") ?>
<h1>
    <?php _e("VIP Resumes", "wpjobboar d") ?> 
    <a class="add-new-h2" href="<?php echo wpjb_admin_url("vipResumes", "add"); ?>"><?php _e("Add New", "wpjobboard") ?></a> 
</h1>
<?php $this->_include("flash.php"); ?>

<form method="post" action="<?php esc_attr_e(wpjb_admin_url("vipResumes", "redirect", null, array("noheader"=>1))) ?>" id="posts-filter">
<p class="search-box">
    <label for="post-search-input" class="hidden">&nbsp;</label>
    <input type="text" value="<?php esc_html_e($query) ?>" name="query" id="post-search-input" class="search-input"/>
    <input type="submit" class="button" value="<?php esc_attr_e("Search by Email", "wpjobboard") ?>" />
</p>
<div class="tablenav">
    <div class="alignleft actions">
        <select name="action" id="wpjb-action1">
            <option selected="selected" value=""><?php _e("Bulk Actions") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
    
        <input type="submit" class="button-secondary action" id="wpjb-doaction1" value="<?php _e("Apply", "wpjobboard") ?>" />
    </div>
</div>
<table cellspacing="0" class="widefat post fixed">
    <?php foreach(array("thead", "tfoot") as $tx): ?>
    <<?php echo $tx; ?>>
        <tr>
            <th class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
            <th class="" scope="col"><?php _e("Email", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Package", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Payment Type", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Started", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Expires", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Status", "wpjobboard") ?></th>
        </tr>
    </<?php echo $tx; ?>>
    <?php endforeach; ?>

    <tbody>
        <?php foreach($data as $i => $item): ?>
	<tr valign="top" class="<?php if($i%2==0): ?>alternate <?php endif; ?>  author-self status-publish iedit">
            <th class="check-column" scope="row">
                <input type="checkbox" value="<?php esc_attr_e($item->getId()) ?>" name="item[]"/>
            </th>
            <td class="post-title column-title">
            
                <a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "index", null, array("email"=>$item->resume_email))) ?>"><?php esc_html_e($item->resume_email) ?></a>               
                <div class="row-actions">
                    <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "delete", $item->getId(), array("noheader"=>1))) ?>" title="<?php _e("Delete", "wpjobboard") ?>" class="wpjb-delete"><?php _e("Delete", "wpjobboard") ?></a> </span>
                    <span class="edit"><a title="<?php _e("Edit", "wpjobboard") ?>" href="<?php echo wpjb_admin_url("vipResumes", "edit", $item->id) ?>"><?php _e("Edit", "wpjobboard") ?></a> | </span>
                    <?php
                        if($item -> status == 0 || $item -> status == 3){
                           ?> <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "decision", $item->getId(), array("noheader"=>1,"decision"=>2))) ?>" title="<?php _e("Approve", "wpjobboard") ?>"><?php _e("Approve", "wpjobboard") ?></a></span>                          
                           <?php
                        }
                        if($item -> status == 2){
                            ?> 
                            <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "decision", $item->getId(), array("noheader"=>1,"decision"=>3))) ?>" title="<?php _e("Disable", "wpjobboard") ?>"><?php _e("Disable", "wpjobboard") ?></a> </span>
                            <?php
                         }
                        
                    ?>
                </div>
            </td>
            <td>
                <a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "index", null, array("package_name"=>$item->package_name))) ?>"><?php esc_html_e($item->package_name) ?></a>           
            </td>
            <td>
                <a href="<?php esc_attr_e(wpjb_admin_url("vipResumes", "index", null, array("payment_type_id"=>$item->package_id))) ?>"><?php esc_html_e($item->payment_type_name) ?></a>           
            </td>

            <td class=""><?php echo wpjb_date($item->started) ?></td>
            <td class=""><?php echo wpjb_date($item->expires) ?></td>
            <td>
                <?php if(strtotime(date("Y-m-d"))-date("Y-m-d", strtotime("{$item->expires}"))<0): ?>
                <span class="wpjb-bulb wpjb-bulb-expired"><?php _e("Expired", "wpjobboard") ?></span>
                <?php elseif($item->status == 0 ): ?>
                <span class="wpjb-bulb wpjb-bulb-inactive"><?php _e("Waiting", "wpjobboard") ?></span>
                <?php elseif($item->status == 3 ): ?>
                <span class="wpjb-bulb wpjb-bulb-inactive"><?php _e("Inactive", "wpjobboard") ?></span>
                <?php else: ?>
                <span class="wpjb-bulb wpjb-bulb-active"><?php _e("Active", "wpjobboard") ?></span>
                <?php endif; ?>
            </td>
            

        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="tablenav">
    <div class="tablenav-pages">
        <?php
        echo paginate_links( array(
            'format' => '&p=%#%',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total,
            'current' => $current,
            'add_args' => false
        ));
        ?>
        
        
    </div>


    <div class="alignleft actions">
        <select name="action2" id="wpjb-action2">
            <option selected="selected" value=""><?php _e("Bulk Actions", "wpjobboard") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
        
        <input type="submit" class="button-secondary action" id="wpjb-doaction2" value="<?php _e("Apply", "wpjobboard") ?>" />
        

    </div>

    <br class="clear"/>
</div>
    
    
</form>