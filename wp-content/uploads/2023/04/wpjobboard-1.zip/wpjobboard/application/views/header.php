
<div class="icon32" id="">
    <img style="height:32px" src="<?php esc_attr_e(plugins_url()."/wpjobboard/public/images/admin-icons/".$this->_renderSlot("logo")) ?>" alt="WPJobBoard Logo" />
</div>
<div class="wpjb-action-container" style="display:none"></div>