<div class="wrap">
    
<?php $this->_include("header.php") ?>
<h1><?php _e("Alert/Interested Job Email Sent/ Subscribtions", "wpjobboar d") ?> </h1>
<?php $this->_include("flash.php"); ?>



<form method="post" action="<?php esc_attr_e(wpjb_admin_url("alertStats", "redirect", null, array("noheader"=>1))) ?>" id="posts-filter">

<ul class="subsubsub">
    <li><a <?php if($campaign == "all"): ?>class="current"<?php endif; ?> href="<?php esc_attr_e(wpjb_admin_url("alertStats", "index", null)) ?>"><?php _e("All", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->all ?>)</span> | </li>
    <li><a <?php if($campaign == "job alert"): ?>class="current"<?php endif; ?>href="<?php esc_attr_e(wpjb_admin_url("alertStats", "index", null, array("campaign"=>"job alert"))) ?>"><?php _e("Job Alerts", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->job_alerts ?>)</span> | </li>
    <li><a <?php if($campaign == "interested job"): ?>class="current"<?php endif; ?>href="<?php esc_attr_e(wpjb_admin_url("alertStats", "index", null, array("campaign"=>"interested job"))) ?>"><?php _e("Interested Jobs", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->interested_jobs ?>)</span> </li>
</ul>
    
<p class="search-box">
    <label for="post-search-input" class="hidden">&nbsp;</label>
    <input type="text" value="<?php esc_html_e($query) ?>" name="query" id="post-search-input" class="search-input"/>
    <input type="submit" class="button" value="<?php esc_attr_e("Search by Email", "wpjobboard") ?>" />
</p>
    
<div class="tablenav">

    <div class="alignleft actions">
        <select name="action" id="wpjb-action1">
            <option selected="selected" value=""><?php _e("Bulk Actions") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
    
        <input type="submit" class="button-secondary action" id="wpjb-doaction1" value="<?php _e("Apply", "wpjobboard") ?>" />
    </div>
    
</div>

<table cellspacing="0" class="widefat post fixed">
    <?php foreach(array("thead", "tfoot") as $tx): ?>
    <<?php echo $tx; ?>>
        <tr>
            <th class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
            <th class="" scope="col"><?php _e("Email", "wpjobboard") ?></th>
            <th class="<?php wpjb_column_sort($sort=="sent_at", $order) ?>" scope="col">
                <a href="<?php esc_attr_e(wpjb_admin_url("alertStats", "index", null, array_merge($param, array("sort"=>"sent_at", "order"=>wpjb_column_order($sort=="sent_at", $order))))) ?>">
                    <span><?php _e("Sent At", "wpjobboard") ?></span>
                    <span class="sorting-indicator"></span>
                </a>
            </th>
        
            <th style="" class="" scope="col"><?php _e("Campaign", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Mail content", "wpjobboard") ?></th>
        </tr>
    </<?php echo $tx; ?>>
    <?php endforeach; ?>

    <tbody>
        <?php foreach($data as $i => $item): ?>
	<tr valign="top" class="<?php if($i%2==0): ?>alternate <?php endif; ?>  author-self status-publish iedit">
            <th class="check-column" scope="row">
                <input type="checkbox" value="<?php esc_attr_e($item->getId()) ?>" name="item[]"/>
            </th>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->email) ?></strong>
                <div class="row-actions">
                    <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("alertStats", "delete", $item->getId(), array("noheader"=>1))) ?>" title="<?php _e("Delete", "wpjobboard") ?>" class="wpjb-delete"><?php _e("Delete", "wpjobboard") ?></a> </span>
                </div>
            </td>

            <td class="date column-date">
                <?php esc_html_e(wpjb_date($item->sent_at)) ?>
            </td>
            <td>
                <?php esc_html_e($item->campaign) ?>
                
            </td>
            <td>
                <?php esc_html_e($item->mail_content) ?>               
            </td>

        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="tablenav">
    <div class="tablenav-pages">
        <?php
        echo paginate_links( array(
            'base' => wpjb_admin_url("alertStats", "index", null, $param)."%_%",
            'format' => '&p=%#%',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total,
            'current' => $current,
            'add_args' => false
        ));
        ?>
        
        
    </div>


    <div class="alignleft actions">
        <select name="action2" id="wpjb-action2">
            <option selected="selected" value=""><?php _e("Bulk Actions", "wpjobboard") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
        
        <input type="submit" class="button-secondary action" id="wpjb-doaction2" value="<?php _e("Apply", "wpjobboard") ?>" />
        

    </div>

    <br class="clear"/>
</div>


</form>


<?php $this->_include("footer.php"); ?>

</div>