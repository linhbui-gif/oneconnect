<div class="wrap">
    
<?php $this->_include("header.php") ?>
<h1><?php _e("Employer Rate", "wpjobboar d") ?> </h1>
<?php $this->_include("flash.php"); ?>



<form method="post" action="<?php esc_attr_e(wpjb_admin_url("employerRate", "redirect", null, array("noheader"=>1))) ?>" id="posts-filter">

<ul class="subsubsub">
    <li><a <?php if($filter == "all"): ?>class="current"<?php endif; ?> href="<?php esc_attr_e(wpjb_admin_url("employerRate", "index", null)) ?>"><?php _e("All", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->all ?>)</span> | </li>
    <li><a <?php if($filter == "waiting"): ?>class="current"<?php endif; ?>href="<?php esc_attr_e(wpjb_admin_url("employerRate", "index", null, array("filter"=>"waiting"))) ?>"><?php _e("Waiting", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->waiting ?>)</span> | </li>
    <li><a <?php if($filter == "approve"): ?>class="current"<?php endif; ?>href="<?php esc_attr_e(wpjb_admin_url("employerRate", "index", null, array("filter"=>"approve"))) ?>"><?php _e("Approve", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->approve ?>)</span> </li>
    <li><a <?php if($filter == "reject"): ?>class="current"<?php endif; ?>href="<?php esc_attr_e(wpjb_admin_url("employerRate", "index", null, array("filter"=>"reject"))) ?>"><?php _e("Reject", "wpjobboard") ?></a><span class="count">(<?php echo (int)$stat->reject ?>)</span> </li>
</ul>
    
<p class="search-box">
    <label for="post-search-input" class="hidden">&nbsp;</label>
    <input type="text" value="<?php esc_html_e($query) ?>" name="query" id="post-search-input" class="search-input"/>
    <input type="submit" class="button" value="<?php esc_attr_e("Search by Company", "wpjobboard") ?>" />
</p>
    
<div class="tablenav">

    <div class="alignleft actions">
        <select name="action" id="wpjb-action1">
            <option selected="selected" value=""><?php _e("Bulk Actions") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
    
        <input type="submit" class="button-secondary action" id="wpjb-doaction1" value="<?php _e("Apply", "wpjobboard") ?>" />
    </div>
    
</div>

<table cellspacing="0" class="widefat post fixed">
    <?php foreach(array("thead", "tfoot") as $tx): ?>
    <<?php echo $tx; ?>>
        <tr>
            <th style="" class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
            <th style="" class="" scope="col"><?php _e("Resume Email", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Company Name", "wpjobboard") ?></th>
            <th style="" class="<?php wpjb_column_sort($sort=="updated_at", $order) ?>" scope="col">
                <a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "index", null, array_merge($param, array("sort"=>"created_at", "order"=>wpjb_column_order($sort=="created_at", $order))))) ?>">
                    <span><?php _e("Evaluated At", "wpjobboard") ?></span>
                    <span class="sorting-indicator"></span>
                </a>
            </th>
            <th style="" class="" scope="col"><?php _e("Status", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Visibility", "wpjobboard") ?></th>
        </tr>
    </<?php echo $tx; ?>>
    <?php endforeach; ?>

    <tbody>
        <?php foreach($data as $i => $item): ?>
	<tr valign="top" class="<?php if($i%2==0): ?>alternate <?php endif; ?>  author-self status-publish iedit">
            <th class="check-column" scope="row">
                <input type="checkbox" value="<?php esc_attr_e($item->getId()) ?>" name="item[]"/>
            </th>
            <td class="post-title column-title">
                <span><?php esc_html_e($item->resume_email) ?></span>
                <div class="row-actions">
                    <span class="view"><a title="<?php _e("View", "wpjobboard") ?>" href="<?php echo wpjb_admin_url("employerRate", "edit", $item->id) ?>"><?php _e("View", "wpjobboard") ?></a> | </span>
                    <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "delete", $item->getId(), array("noheader"=>1))) ?>" title="<?php _e("Delete", "wpjobboard") ?>" class="wpjb-delete"><?php _e("Delete", "wpjobboard") ?></a> </span>
                    <br>
                    <?php
                        if($item -> status == 0){
                           ?> <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "decision", $item->getId(), array("noheader"=>1,"decision"=>2))) ?>" title="<?php _e("Approve", "wpjobboard") ?>"><?php _e("Approve", "wpjobboard") ?></a> </span>
                           <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "decision", $item->getId(), array("noheader"=>1,"decision"=>1))) ?>" title="<?php _e("Reject", "wpjobboard") ?>"><?php _e("Reject", "wpjobboard") ?></a> </span>
                           <?php
                        }
                        if($item -> status == 2){
                            ?> 
                            <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "decision", $item->getId(), array("noheader"=>1,"decision"=>1))) ?>" title="<?php _e("Reject", "wpjobboard") ?>"><?php _e("Reject", "wpjobboard") ?></a> </span>
                            <br>
                            <?php
                            if($item->show_review == 1){
                                ?>
                                <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "visibility", $item->getId(), array("noheader"=>1,"visibility"=>0))) ?>" title="<?php _e("Hide", "wpjobboard") ?>"><?php _e("Hide", "wpjobboard") ?></a> </span>
                                <br>
                                <?php
                            }
                            if($item->show_review == 0){
                                ?>
                                <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "visibility", $item->getId(), array("noheader"=>1,"visibility"=>1))) ?>" title="<?php _e("Display", "wpjobboard") ?>"><?php _e("Display", "wpjobboard") ?></a> </span>
                                <br>
                                <?php
                            }
                        }
                        if($item -> status == 1){
                        ?> 
                        <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("employerRate", "decision", $item->getId(), array("noheader"=>1,"decision"=>2))) ?>" title="<?php _e("Approve", "wpjobboard") ?>"><?php _e("Approve", "wpjobboard") ?></a> </span>
                        <?php
                        }
                    ?>
                </div>
            </td>
            <td class="post-title column-title">
                <span><?php esc_html_e($item->company_name) ?></span>        
            </td>

            <td class="date column-date">
                <?php esc_html_e(wpjb_date($item->updated_at)) ?>
            </td>
            <td class="post-title column-title">
                <?php 
                    if($item->status == 0){
                        $status = "waiting";
                    }
                    if($item->status == 1){
                        $status = "reject";
                    }
                    if($item->status == 2){
                        $status = "approve";
                    }
                ?>
                <strong><?php esc_html_e($status) ?></strong>        
            </td>
            <td class="post-title column-title">
                <?php 
                    if($item->show_review == 0){
                        $status = "Hide";
                    }
                    if($item->show_review == 1){
                        $status = "Display";
                    }
                ?>
                <strong><?php esc_html_e($status) ?></strong>        
            </td>
            
            
            

        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="tablenav">
    <div class="tablenav-pages">
        <?php
        echo paginate_links( array(
            'base' => wpjb_admin_url("employerRate", "index", null, $param)."%_%",
            'format' => '&p=%#%',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total,
            'current' => $current,
            'add_args' => false
        ));
        ?>
        
        
    </div>


    <div class="alignleft actions">
        <select name="action2" id="wpjb-action2">
            <option selected="selected" value=""><?php _e("Bulk Actions", "wpjobboard") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
        
        <input type="submit" class="button-secondary action" id="wpjb-doaction2" value="<?php _e("Apply", "wpjobboard") ?>" />
        

    </div>

    <br class="clear"/>
</div>


</form>


<?php $this->_include("footer.php"); ?>

</div>