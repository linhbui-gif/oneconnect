<div class="wrap">
    
<?php $this->_include("header.php") ?>
<h1><?php _e("E-mail Employer Decision", "wpjobboar d") ?> </h1>
<?php $this->_include("flash.php"); ?>



<form method="post" action="<?php esc_attr_e(wpjb_admin_url("employerDecisions", "redirect", null, array("noheader"=>1))) ?>" id="posts-filter">
    
<p class="search-box">
    <label for="post-search-input" class="hidden">&nbsp;</label>
    <input type="text" value="<?php esc_html_e($query) ?>" name="query" id="post-search-input" class="search-input"/>
    <input type="submit" class="button" value="<?php esc_attr_e("Search by Job", "wpjobboard") ?>" />
</p>

<table cellspacing="0" class="widefat post fixed">
    <?php foreach(array("thead", "tfoot") as $tx): ?>
    <<?php echo $tx; ?>>
        <tr>
            <th class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
            <th class="" scope="col"><?php _e("Email", "wpjobboard") ?></th>
            <th class="<?php wpjb_column_sort($sort=="created_at", $order) ?>" scope="col">
                <a href="<?php esc_attr_e(wpjb_admin_url("employerDecisions", "index", null, array_merge($param, array("sort"=>"created_at", "order"=>wpjb_column_order($sort=="created_at", $order))))) ?>">
                    <span><?php _e("Created At", "wpjobboard") ?></span>
                    <span class="sorting-indicator"></span>
                </a>
            </th>
            <th style="" class="" scope="col"><?php _e("Job Title", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Company Name", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Status", "wpjobboard") ?></th>
        </tr>
    </<?php echo $tx; ?>>
    <?php endforeach; ?>

    <tbody>
        <?php foreach($data as $i => $item): ?>
	<tr valign="top" class="<?php if($i%2==0): ?>alternate <?php endif; ?>  author-self status-publish iedit">
            <th class="check-column" scope="row">
                <input type="checkbox" value="<?php esc_attr_e($item->getId()) ?>" name="item[]"/>
            </th>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->email) ?></strong>               
            </td>

            <td class="date column-date">
                <?php esc_html_e(wpjb_date($item->created_at)) ?>
            </td>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->job_title) ?></strong>               
            </td>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->company_name) ?></strong>               
            </td>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->status) ?></strong>               
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="tablenav">
    <div class="tablenav-pages">
        <?php
        echo paginate_links( array(
            'base' => wpjb_admin_url("employerDecisions", "index", null, $param)."%_%",
            'format' => '&p=%#%',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total,
            'current' => $current,
            'add_args' => false
        ));
        ?>
        
        
    </div>

    <br class="clear"/>
</div>


</form>


<?php $this->_include("footer.php"); ?>

</div>