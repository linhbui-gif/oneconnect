<div class="wrap">
    
<?php $this->_include("header.php") ?>
    <h1>
        <?php if($form->getObject()->id): ?>
        <?php _e("View Employer Rate", "wpjobboard"); ?> 
        <?php endif; ?>
    </h1>
<?php $this->_include("flash.php"); ?>
<?php $employer_rate = new Wpjb_Model_EmployerRate($form->getObject()->id)?>
<form action="" method="post" class="wpjb-form">
    <table class="form-table">
        <tbody>
            <tr valign="top">
                <th scope="row">
                    <label for="email">Email</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->resume_email;?></span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="company">Company</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->company_name;?></span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="evaluate_at">Evaluated At</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->updated_at;?></span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="title">Review Title</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->review_title;?></span>
                </td>
                
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="pos_review">Positive Review</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->positive_review?></span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="neg_review">Negative Review</label>
                </th>
                <td>
                    <span><?php echo $employer_rate->negative_review?></span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="rating">rating</label>
                </th>
                <td class="post-title column-title">
                    <p>
                        <span>Overall: </span>
                        <span><?php echo $employer_rate->overall_rating?></span>
                    </p>
                    <p>
                        <span>Salary: </span>
                        <span><?php echo $employer_rate->salary_rating?></span>
                    </p>
                    <p>
                        <span>Company culture: </span>
                        <span><?php echo $employer_rate->culture_rating?></span>
                    </p>
                    <p>
                        <span>Training & learning: </span>
                        <span><?php echo $employer_rate->training_rating?></span>
                    </p>
                    <p>
                        <span>Curriculum: </span>
                        <span><?php echo $employer_rate->curriculum_rating?></span>
                    </p>
                    <p>
                        <span>Employee care: </span>
                        <span><?php echo $employer_rate->employer_care_rating?></span>
                    </p>
                    <p>
                        <span>Office: </span>
                        <span><?php echo $employer_rate->office_rating?></span>
                    </p>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="status">rating</label>
                </th>
                <td class="post-title column-title">
                    <?php 
                        if($employer_rate->status == 0){
                            $status = "Waiting";
                        }
                        if($employer_rate->status == 1){
                            $status = "Rejected";
                        }
                        if($employer_rate->status == 2){
                            $status = "Approved";
                        }
                    ?>
                    <strong><?php esc_html_e($status) ?></strong>        
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="visibility">Visibility</label>
                </th>
                <td class="post-title column-title">
                    <?php 
                        if($employer_rate->show_review == 0){
                            $status = "Hide";
                        }
                        if($employer_rate->show_review == 1){
                            $status = "Display";
                        }
                    ?>
                    <strong><?php esc_html_e($status) ?></strong>            
                </td>
            </tr>
        </tbody>
    </table>

</form>

<?php $this->_include("footer.php"); ?>