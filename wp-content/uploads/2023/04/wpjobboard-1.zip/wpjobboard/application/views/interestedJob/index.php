<div class="wrap">
    
<?php $this->_include("header.php") ?>
<h1><?php _e("E-mail Interested Job", "wpjobboar d") ?> </h1>
<?php $this->_include("flash.php"); ?>



<form method="post" action="<?php esc_attr_e(wpjb_admin_url("interestedJob", "redirect", null, array("noheader"=>1))) ?>" id="posts-filter">
    
<p class="search-box">
    <label for="post-search-input" class="hidden">&nbsp;</label>
    <input type="text" value="<?php esc_html_e($query) ?>" name="query" id="post-search-input" class="search-input"/>
    <input type="submit" class="button" value="<?php esc_attr_e("Search by email", "wpjobboard") ?>" />
</p>

<table cellspacing="0" class="widefat post fixed">
    <?php foreach(array("thead", "tfoot") as $tx): ?>
    <<?php echo $tx; ?>>
        <tr>
            <th class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
            <th class="" scope="col"><?php _e("Email", "wpjobboard") ?></th>      
            <th style="" class="" scope="col"><?php _e("Status", "wpjobboard") ?></th>
            <th style="" class="" scope="col"><?php _e("Params", "wpjobboard") ?></th>
        </tr>
    </<?php echo $tx; ?>>
    <?php endforeach; ?>

    <tbody>
        <?php foreach($data as $i => $item): 
            $resume = new Wpjb_Model_Resume($item->resumeid);
            if(empty($resume)) continue;
        ?>
            
	    <tr valign="top" class="<?php if($i%2==0): ?>alternate <?php endif; ?>  author-self status-publish iedit">
            <th class="check-column" scope="row">
                <input type="checkbox" value="<?php esc_attr_e($item->id) ?>" name="item[]"/>
            </th>
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->email) ?></strong>    
                <div class="row-actions">
                    <span class=""><a href="<?php esc_attr_e(wpjb_admin_url("interestedJob", "delete", $item->getId(), array("noheader"=>1))) ?>" title="<?php _e("Delete", "wpjobboard") ?>" class="wpjb-delete"><?php _e("Delete", "wpjobboard") ?></a> </span>
                </div>   
            </td>
            
            <td class="post-title column-title">
                <strong><?php esc_html_e($item->job_interested == 1 ? 'ON' : 'OFF') ?></strong>               
            </td>

            <td>
                <?php
                    $job_category = $resume->meta->field_job_category->values();
                    $job_type = $resume->meta->field_job_type->values();
                    $job_city = $resume->meta->interested_job_city->values();
                    echo "<strong>Job category</strong>: ".esc_html(join(", ",  $job_category))."<br/>";
                    echo "<strong>Job type</strong>: ".esc_html(join(", ",   $job_type))."<br/>";
                    echo "<strong>Job city</strong>: ".esc_html(join(", ",  $job_city))."<br/>";
                ?>
            
            </td>

        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="tablenav">
    <div class="tablenav-pages">
        <?php
        echo paginate_links( array(
            'base' => wpjb_admin_url("interestedJob", "index", null, $param)."%_%",
            'format' => '&p=%#%',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total,
            'current' => $current,
            'add_args' => false
        ));
        ?>
        
        
    </div>
    <div class="alignleft actions">
        <select name="action2" id="wpjb-action2">
            <option selected="selected" value=""><?php _e("Bulk Actions", "wpjobboard") ?></option>
            <option value="delete"><?php _e("Delete", "wpjobboard") ?></option>
        </select>
        
        <input type="submit" class="button-secondary action" id="wpjb-doaction2" value="<?php _e("Apply", "wpjobboard") ?>" />
        

    </div>

    <br class="clear"/>
</div>


</form>
<form action="<?php esc_attr_e(wpjb_admin_url("interestedJob", "turnOff", null, array("noheader"=>1))) ?>" method="post" enctype="multipart/form-data">
      <input type="file" name="fileToUpload" id="fileToUpload" accept=".txt">
      <input type="submit" value="Turn off alerts" name="submit">
</form>


<?php $this->_include("footer.php"); ?>

</div>