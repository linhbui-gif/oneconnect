SET FOREIGN_KEY_CHECKS =0; --

DROP TABLE `{$wpdb->prefix}wpjb_alert` ; --
DROP TABLE `{$wpdb->prefix}wpjb_application` ; --
DROP TABLE `{$wpdb->prefix}wpjb_company` ; --
DROP TABLE `{$wpdb->prefix}wpjb_discount` ; --
DROP TABLE `{$wpdb->prefix}wpjb_import` ; --
DROP TABLE `{$wpdb->prefix}wpjb_job` ; --
DROP TABLE `{$wpdb->prefix}wpjb_job_search` ; --
DROP TABLE `{$wpdb->prefix}wpjb_mail` ; --
DROP TABLE `{$wpdb->prefix}wpjb_meta` ; --
DROP TABLE `{$wpdb->prefix}wpjb_meta_value` ; --
DROP TABLE `{$wpdb->prefix}wpjb_payment` ; --
DROP TABLE `{$wpdb->prefix}wpjb_pricing` ; --
DROP TABLE `{$wpdb->prefix}wpjb_resume` ; --
DROP TABLE `{$wpdb->prefix}wpjb_resume_detail` ; --
DROP TABLE `{$wpdb->prefix}wpjb_resume_search` ; --
DROP TABLE `{$wpdb->prefix}wpjb_tag` ; --
DROP TABLE `{$wpdb->prefix}wpjb_tagged` ; --
DROP TABLE `{$wpdb->prefix}wpjb_membership` ; --
DROP TABLE `{$wpdb->prefix}wpjb_shortlist` ; --